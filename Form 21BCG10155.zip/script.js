const age = document.getElementById('age')
const reason = document.getElementById('reason')
const email = document.getElementById('email')
const phnno = document.getElementById('phnno')
const form = document.getElementById('form')

const errorElement = document.getElementById('error')

form.addEventListener('submit', (e) => {
    let messages=[]
    if(age.value<=13){
        messages.push('Age must be More than 13 for a Student to fill this form')
    }
    if(messages.length>0){
        e.preventDefault()
        errorElement.innerText = messages.join(', ')
    }
})